import{C as e,R as t,V as n,p as r,t as i,u as a}from"./index-CPVueDDP.js";import{r as o,t as s}from"./Card-D-NwLnES.js";import{t as c}from"./StatTile-D0ndPvO5.js";import{t as l}from"./Badge-C4trJP58.js";var u=n(t(),1),d=a(),f={Aktif:`positive`,Beta:`warning`,Yakında:`neutral`},p=[`Tümü`,`REST`,`SOAP`];function m(e,t,n){let r=new Blob([t],{type:n}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=e,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(i)}function h(e){let t=e.endpoints.map(e=>`| ${e.method} | \`${e.path}\` | ${e.desc} |`).join(`
`),n=e.protocol===`REST`?`\`\`\`http\nGET ${e.baseUrl}/api/v1/cari?limit=50\nAuthorization: Bearer <token>\nX-Firma-No: 001\nAccept: application/json\n\`\`\``:`\`\`\`xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
  <soapenv:Body>
    <GetCariListesi>
      <FirmaNo>001</FirmaNo>
      <Donem>2026</Donem>
    </GetCariListesi>
  </soapenv:Body>
</soapenv:Envelope>
\`\`\``,r=e.format===`JSON`?`\`\`\`json
{
  "cari": [
    { "kod": "120.001", "unvan": "Anadolu Ambalaj San. A.Ş.", "bakiye": -46600.00, "para": "TRY" }
  ],
  "toplam": 1
}
\`\`\``:`\`\`\`xml
<Cari>
  <Kod>120.001</Kod>
  <Unvan>Anadolu Ambalaj San. A.Ş.</Unvan>
  <Bakiye>-46600.00</Bakiye>
</Cari>
\`\`\``;return`# ${e.name} — Web Servis Entegrasyon Dokümanı

> Akort · Açık Bankacılık — API Hub
> Üretici: ${e.vendor} · Kategori: ${e.category} · Durum: ${e.status}

## 1. Genel bilgiler

| Alan | Değer |
| --- | --- |
| Protokol | ${e.protocol} |
| Sürüm | ${e.version} |
| Base URL | \`${e.baseUrl}\` |
| Kimlik doğrulama | ${e.auth} |
| Veri formatı | ${e.format} |

${e.note}

## 2. Kimlik doğrulama

Entegrasyon ${e.auth} yöntemini kullanır. Kimlik bilgileri Akort › Admin panel › API anahtarları üzerinden
oluşturulur ve her istekte iletilir. Üretim ortamında IP kısıtlaması ve TLS 1.2+ zorunludur.

## 3. Uç noktalar

| Metod | Yol / Operasyon | Açıklama |
| --- | --- | --- |
${t}

## 4. Örnek istek

${n}

## 5. Örnek yanıt

${r}

## 6. Hata kodları

| Kod | Anlamı |
| --- | --- |
| 200 / OK | Başarılı |
| 401 | Kimlik doğrulama hatası (token süresi dolmuş olabilir) |
| 403 | Yetkisiz firma / dönem |
| 409 | Kayıt zaten mevcut (idempotency) |
| 422 | Doğrulama hatası (zorunlu alan eksik) |
| 500 | ERP tarafı hatası — destek ile iletişime geçin |

---
_Bu doküman Akort API Hub tarafından otomatik oluşturulmuştur · ${new Date().toLocaleDateString(`tr-TR`)}_
`}function g(e){let t={};for(let n of e.endpoints)t[n.path]={[n.method.toLowerCase()]:{summary:n.desc,responses:{200:{description:`Başarılı`}}}};return JSON.stringify({openapi:`3.0.3`,info:{title:`${e.name} — Akort Entegrasyonu`,version:e.version},servers:[{url:e.baseUrl}],components:{securitySchemes:{auth:{type:`http`,scheme:`bearer`,description:e.auth}}},security:[{auth:[]}],paths:t},null,2)}function _(e){let t=e.endpoints.map(e=>`    <operation name="${e.path}"><!-- ${e.desc} --></operation>`).join(`
`);return`<?xml version="1.0" encoding="UTF-8"?>
<!-- ${e.name} — Akort entegrasyon WSDL taslağı · ${e.auth} -->
<definitions name="${e.id}"
  targetNamespace="${e.baseUrl}"
  xmlns="http://schemas.xmlsoap.org/wsdl/"
  xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/">
  <portType name="${e.id}PortType">
${t}
  </portType>
  <service name="${e.name.replace(/[^A-Za-z0-9]/g,``)}">
    <port name="${e.id}Port"><soap:address location="${e.baseUrl}"/></port>
  </service>
</definitions>
`}function v(){let[t,n]=(0,u.useState)(`Tümü`),[a,v]=(0,u.useState)(``),[b,x]=(0,u.useState)(null),S=(0,u.useMemo)(()=>{let n=a.trim().toLowerCase();return e.filter(e=>!(t!==`Tümü`&&e.protocol!==t||n&&!`${e.name} ${e.vendor} ${e.category}`.toLowerCase().includes(n)))},[t,a]);return(0,d.jsxs)(`div`,{className:`space-y-6`,children:[(0,d.jsxs)(`div`,{className:`grid grid-cols-2 gap-4 lg:grid-cols-4`,children:[(0,d.jsx)(c,{label:`Bağlı ERP`,value:r.connectedErp,hint:`${e.length} entegrasyon mevcut`}),(0,d.jsx)(c,{label:`Aktif uç nokta`,value:r.activeEndpoints,hint:`REST + SOAP`}),(0,d.jsx)(c,{label:`Aylık API çağrısı`,value:r.monthlyCalls,hint:`son 30 gün`}),(0,d.jsx)(c,{label:`Ort. yanıt süresi`,value:`${r.avgLatencyMs} ms`,hint:`p95 · sağlıklı`,tone:`positive`})]}),(0,d.jsxs)(s,{children:[(0,d.jsxs)(`div`,{className:`mb-4 flex flex-wrap items-center justify-between gap-3`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(o,{children:`API Hub`}),(0,d.jsx)(`p`,{className:`text-xs text-muted`,children:`Tüm ERP'ler için web servis dokümanları — Markdown, OpenAPI (REST) veya WSDL (SOAP) olarak indirin.`})]}),(0,d.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,d.jsx)(`input`,{value:a,onChange:e=>v(e.target.value),placeholder:`ERP ara…`,className:`input w-40 sm:w-52`}),(0,d.jsx)(`div`,{className:`flex gap-1 rounded-xl bg-cream-100 p-1`,children:p.map(e=>(0,d.jsx)(`button`,{onClick:()=>n(e),className:`rounded-lg px-3 py-1.5 text-xs font-bold transition-colors ${t===e?`bg-white text-ink-900 shadow-sm`:`text-ink-900/50`}`,children:e},e))})]})]}),(0,d.jsx)(`div`,{className:`grid grid-cols-1 gap-4 lg:grid-cols-2`,children:S.map(e=>{let t=b===e.id;return(0,d.jsxs)(`div`,{className:`rounded-2xl border border-line p-4`,children:[(0,d.jsxs)(`div`,{className:`flex items-start justify-between gap-3`,children:[(0,d.jsxs)(`div`,{className:`flex min-w-0 items-center gap-3`,children:[(0,d.jsx)(`span`,{className:`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-extrabold text-white`,style:{backgroundColor:e.colorHex},children:e.name.slice(0,2).toUpperCase()}),(0,d.jsxs)(`div`,{className:`min-w-0`,children:[(0,d.jsx)(`p`,{className:`truncate font-display text-sm font-bold text-ink-900`,children:e.name}),(0,d.jsxs)(`p`,{className:`truncate text-xs text-muted`,children:[e.vendor,` · `,e.category]})]})]}),(0,d.jsx)(l,{tone:f[e.status],children:e.status})]}),(0,d.jsxs)(`div`,{className:`mt-3 flex flex-wrap gap-1.5`,children:[(0,d.jsx)(y,{children:e.protocol}),(0,d.jsx)(y,{children:e.version}),(0,d.jsx)(y,{children:e.format}),(0,d.jsx)(y,{children:e.auth})]}),(0,d.jsx)(`button`,{onClick:()=>x(t?null:e.id),className:`mt-3 text-xs font-semibold text-brand-500 hover:underline`,children:t?`Uç noktaları gizle ▲`:`${e.endpoints.length} uç noktayı gör ▼`}),t&&(0,d.jsx)(`div`,{className:`mt-3 overflow-hidden rounded-xl border border-line`,children:(0,d.jsx)(`table`,{className:`w-full text-xs`,children:(0,d.jsx)(`tbody`,{className:`divide-y divide-line`,children:e.endpoints.map((e,t)=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{className:`w-16 whitespace-nowrap px-3 py-2 font-mono font-bold text-brand-600`,children:e.method}),(0,d.jsx)(`td`,{className:`px-3 py-2 font-mono text-ink-900/80`,children:e.path}),(0,d.jsx)(`td`,{className:`hidden px-3 py-2 text-muted sm:table-cell`,children:e.desc})]},t))})})}),(0,d.jsxs)(`div`,{className:`mt-4 flex flex-wrap gap-2`,children:[(0,d.jsx)(i,{size:`sm`,variant:`primary`,onClick:()=>m(`${e.id}-web-servis.md`,h(e),`text/markdown;charset=utf-8`),disabled:e.status===`Yakında`,children:`↓ Doküman (.md)`}),e.protocol===`REST`?(0,d.jsx)(i,{size:`sm`,variant:`secondary`,onClick:()=>m(`${e.id}-openapi.json`,g(e),`application/json;charset=utf-8`),disabled:e.status===`Yakında`,children:`↓ OpenAPI (.json)`}):(0,d.jsx)(i,{size:`sm`,variant:`secondary`,onClick:()=>m(`${e.id}.wsdl`,_(e),`application/xml;charset=utf-8`),disabled:e.status===`Yakında`,children:`↓ WSDL (.xml)`})]})]},e.id)})}),S.length===0&&(0,d.jsx)(`p`,{className:`py-10 text-center text-sm text-muted`,children:`Aramanızla eşleşen ERP bulunamadı.`})]})]})}function y({children:e}){return(0,d.jsx)(`span`,{className:`rounded-full bg-cream-100 px-2.5 py-1 text-[11px] font-semibold text-ink-900/70`,children:e})}export{v as AdminPanel};